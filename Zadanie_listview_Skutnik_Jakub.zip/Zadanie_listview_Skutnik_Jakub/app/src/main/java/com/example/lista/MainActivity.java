package com.example.lista;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class MainActivity extends AppCompatActivity {
    public int licznik=0;
    public String getPathFromURI(Uri contentUri) {
        String res = null;
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor.moveToFirst()) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            res = cursor.getString(column_index);
        }
        cursor.close();
        return res;
    }

    String[] maintitle={};
    private ImageView mImageView;

//bind imageview with your xml's id



    public Uri[] imgid ={};
    ListView list;
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {

            if (resultCode == RESULT_OK) {
                if (requestCode == REQUEST_GET_SINGLE_FILE) {
                    Uri selectedImageUri = data.getData();
                    // Get the path from the Uri
                    final String path = getPathFromURI(selectedImageUri);
                    if (path != null) {
                        File f = new File(path);

                        selectedImageUri = Uri.fromFile(f);
                        if (resultCode == RESULT_OK)
                        {

                            Uri imageUri = data.getData();
                            maintitle[licznik]+=selectedImageUri.toString();
                            imgid[0]=selectedImageUri;
                        }

                    }
                    // Set the image in ImageView

licznik++;

                }

            }
            Toast.makeText(this,imgid.toString(),Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Log.e("FileSelectorActivity", "File select error", e);
        }




        Toast.makeText(this,maintitle[licznik],Toast.LENGTH_LONG).show();

    }




    @Override

    public void onCreate(Bundle savedInstanceState) {

        MyListAdapter adapter = new MyListAdapter(this, maintitle, imgid);
        list.setAdapter(adapter);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        final Button button = findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), REQUEST_GET_SINGLE_FILE);


ListView x =findViewById(R.id.list);
mImageView=(findViewById(R.id.imageView1ID));
mImageView.getDrawable();


                // Code here executes on main thread after user presses button
            }

        });


    }

    private static final int REQUEST_GET_SINGLE_FILE = 1;



}